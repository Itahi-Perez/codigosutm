<?php
if(!empty($_POST)){
    if(isset($_POST['ID'])){
        require_once "conectar.php";
            $db = conectaDB();

            $idIng = $_POST['ID'];
            //print"$idIng";
                    
            $consulta = "SELECT ID FROM NOTICIA WHERE ID = .$idIng";
            $result = $db->query($consulta);
            //print"$result";
            if(!$result){ //significa que no existe el ID seleccionado
                //print"<p>El ID seleccionado no existe en la base de datos.</p>\n";
                //print"<a href='eliminar.php'>Pagina Principal.</a>";
                
            }else{
                $consulta2 = "DELETE FROM NOTICIA WHERE ID = $idIng";
                $consulta3 = "DELETE FROM COMENTARIOS WHERE IDN = '$idIng'";
                $result2 = $db->query($consulta2);
                $result3 = $db->query($consulta3);
                if(!$result2 and !$result3){//significa que no se pudo eliminar
                    print "<p>Error no se elimino la noticia y comentarios de manera exitosa.</p>\n";
                }else{
                    
                    print"<p>Eliminacion de la noticia y comentarios EXITOSA</p>\n";
                    
                }
                
            }
            print"<p><a href='eliminar.php'>Atras</a></p>\n";
            print"<p><a href='modificaciones.php'>Pagina Principal</a></p>";
    }
}else{
    header("location:eliminar.php");
}
?>
