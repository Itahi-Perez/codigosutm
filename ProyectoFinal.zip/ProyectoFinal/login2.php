<?php
if(!empty($_POST)){
	if(isset($_POST['user']) and isset($_POST['password'])){
		if($_POST['user']!="" && $_POST['password']!=""){
			include "conectar.php";
			require_once "conectar.php";
			$db = conectaDB();
			$user_id=null;
			$usuario=$_POST['user'];
			$pass=$_POST['password'];
			$sql1= "select * from USUARIOS where usuario='$usuario' and contraseña='$pass' ";
			$query = $db->query($sql1);
			
			while ($r = $query->fetch(PDO::FETCH_ASSOC)) {
				$user_id=$r["id"];
				break;
			}
			if($user_id==null){
			    header("location:login.php");
			}else{
				session_start();
				$_SESSION["user_id"]=$user_id;
				$_SESSION["logueando"]=TRUE;
				header("location:modificaciones.php"); 			
			}
		}
		else
	    {
            header("location:login.php");
        }
	}
}
else{
   header("location:login.php");
}

?>