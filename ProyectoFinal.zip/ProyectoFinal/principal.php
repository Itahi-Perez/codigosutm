<?php
require_once 'conectar.php';
$db = conectaDb();

$seccion = "DEPORTES";
if(isset($_POST['seccion'])){
	$seccion = $_POST['seccion'];
}
$consulta1 = "SELECT IMAGEN, NOMBRE_NOTICIA, ID FROM NOTICIA WHERE SECCION='$seccion' ORDER BY LIKES DESC";
$result1 = $db->query($consulta1);
if(!$result1){
	print "<p>Error en la consulta destacados</p>\n";
}

$consulta2 = "SELECT FECHA, NOMBRE_NOTICIA, ID FROM NOTICIA ORDER BY fecha DESC";
$result2 = $db->query($consulta2);
if(!$result2){
	print "<p>Error en la consulta recientes</p>\n";
}

$db = null;

foreach($result1 as $valores1){
    $destacados['IMAGEN'][] = $valores1['IMAGEN'];
    $destacados['NOMBRE_NOTICIA'][] = $valores1['NOMBRE_NOTICIA'];
    $destacados['ID'][] = $valores1['ID'];
}

foreach ($result2 as $valores2) {
	$recientes['FECHA'][] = $valores2['FECHA'];
	$recientes['NOMBRE_NOTICIA'][] = $valores2['NOMBRE_NOTICIA'];
	$recientes['ID'][] = $valores2['ID'];
}

//print_r($destacados);
//print_r($recientes);

print "<!DOCTYPE html>
<html lang=\"en\">
  <head>
    <meta charset=\"utf-8\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1, shrink-to-fit=no\">

    <link rel=\"stylesheet\" href=\"https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css\" integrity=\"sha384-GJzZqFGwb1QTTN6wy59ffF1BuGJpLSa9DkKMp0DgiMDm4iYMj70gZWKYbI706tWS\" crossorigin=\"anonymous\">
    <link rel=\"stylesheet\" type=\"text/css\" href=\"principal-style.css\">

    <title>Notix</title>
  </head>
  <body>
  	<div class=\"container-fluid\">
		<div class=\"row titulo\">
	    	<div class=\"col-lg-2 col-md-2 col-sm-3 col-xs-12\">
	      		<img class=\"img-fluid\" src=\"http://www.vientodelibertad.org/IMG/arton3577.png\" >
	    	</div>
	    	<div class=\"col\">
	    		<h1>NOTICIAS, VOZ E IMÁGEN</h1>
	    	</div>
	  	</div>
	  	<div class=\"row justify-content-end\">
	    	<div class=\"btn-group btn-group-toggle\" data-toggle=\"buttons\">
					<label class=\"btn btn-info btn-sm active\">
					    <form action=\"\" method=\"post\" enctype=\"multipart/form-data\">
						    <input type=\"hidden\" name=\"seccion\" value=\"DEPORTES\">
						    <button type=\"submit\">DEPORTES</button>
						</form>
					</label>
					<label class=\"btn btn-info btn-sm\">
						<form action=\"\" method=\"post\" enctype=\"multipart/form-data\">
						    <input type=\"hidden\" name=\"seccion\" value=\"POLITICA\">
						    <button type=\"submit\">POLÍTICA</button>
						</form>
					</label>
					<label class=\"btn btn-info btn-sm\">
					    <form action=\"\" method=\"post\" enctype=\"multipart/form-data\">
						    <input type=\"hidden\" name=\"seccion\" value=\"CULTURA\">
						    <button type=\"submit\">CULTURA</button>
						</form>
					</label>
			</div>
	  	</div>
	</div>

	<div class=\"container-fluid main\">
		<div class=\"row\">
			<div class=\"container-fluid relevante col-lg-9 col-md-9 col-sm-8 col-xs-12\">
				<div class=\"row\">
			    	<div class=\"cuadri col\">
			    		<img src=\"".$destacados['IMAGEN'][0]."\" alt=\"\" class=\"image\">
			    		<div class=\"resumen\">".$destacados['NOMBRE_NOTICIA'][0]."</div>
			    		<a href=\"https://perds.000webhostapp.com/ProyectoFinal/miparte.php/?ID=".$destacados['ID'][0]."\"><div class=\"overlay\">
							<div class=\"text\">Ver mas...</div>
						</div></a>
			    	</div>
			    	<div class=\"cuadri col\">
			    		<img src=\"".$destacados['IMAGEN'][1]."\" alt=\"\" class=\"image\">
			    		<div class=\"resumen\">".$destacados['NOMBRE_NOTICIA'][1]."</div>
			    		<a href=\"https://perds.000webhostapp.com/ProyectoFinal/miparte.php/?ID=".$destacados['ID'][1]."\"><div class=\"overlay\">
							<div class=\"text\">Ver mas...</div>
						</div></a>
			    	</div>
			    	<div class=\"cuadri col\">
			    		<img src=\"".$destacados['IMAGEN'][2]."\" alt=\"\" class=\"image\">
			    		<div class=\"resumen\">".$destacados['NOMBRE_NOTICIA'][2]."</div>
			    		<a href=\"https://perds.000webhostapp.com/ProyectoFinal/miparte.php/?ID=".$destacados['ID'][2]."\"><div class=\"overlay\">
							<div class=\"text\">Ver mas...</div>
						</div></a>
			    	</div>
			  	</div>
			  	<div class=\"row\">
			    	<div class=\"cuadri col\">
			    		<img src=\"".$destacados['IMAGEN'][3]."\" alt=\"\" class=\"image\">
			    		<div class=\"resumen\">".$destacados['NOMBRE_NOTICIA'][3]."</div>
			    		<a href=\"https://perds.000webhostapp.com/ProyectoFinal/miparte.php/?ID=".$destacados['ID'][3]."\"><div class=\"overlay\">
							<div class=\"text\">Ver mas...</div>
						</div></a>
			    	</div>
			    	<div class=\"cuadri col\">
			    		<img src=\"".$destacados['IMAGEN'][4]."\" alt=\"\" class=\"image\">
			    		<div class=\"resumen\">".$destacados['NOMBRE_NOTICIA'][4]."</div>
			    		<a href=\"https://perds.000webhostapp.com/ProyectoFinal/miparte.php/?ID=".$destacados['ID'][4]."\"><div class=\"overlay\">
							<div class=\"text\">Ver mas...</div>
						</div></a>
			    	</div>
			    	<div class=\"cuadri col\">
			    		<img src=\"".$destacados['IMAGEN'][5]."\" alt=\"\" class=\"image\">
			    		<div class=\"resumen\">".$destacados['NOMBRE_NOTICIA'][5]."</div>
			    		<a href=\"https://perds.000webhostapp.com/ProyectoFinal/miparte.php/?ID=".$destacados['ID'][5]."\"><div class=\"overlay\">
							<div class=\"text\">Ver mas...</div>
						</div></a>
			    	</div>
			  	</div>
			  	<div class=\"row\">
			    	<div class=\"cuadri col\">
			    		<img src=\"".$destacados['IMAGEN'][6]."\" alt=\"\" class=\"image\">
			    		<div class=\"resumen\">".$destacados['NOMBRE_NOTICIA'][6]."</div>
			    		<a href=\"https://perds.000webhostapp.com/ProyectoFinal/miparte.php/?ID=".$destacados['ID'][6]."\"><div class=\"overlay\">
							<div class=\"text\">Ver mas...</div>
						</div></a>
			    	</div>
			    	<div class=\"cuadri col\">
			    		<img src=\"".$destacados['IMAGEN'][7]."\" alt=\"\" class=\"image\">
			    		<div class=\"resumen\">".$destacados['NOMBRE_NOTICIA'][7]."</div>
			    		<a href=\"https://perds.000webhostapp.com/ProyectoFinal/miparte.php/?ID=".$destacados['ID'][7]."\"><div class=\"overlay\">
							<div class=\"text\">Ver mas...</div>
						</div></a>
			    	</div>
			    	<div class=\"cuadri col\">
			    		<img src=\"".$destacados['IMAGEN'][8]."\" alt=\"\" class=\"image\">
			    		<div class=\"resumen\">".$destacados['NOMBRE_NOTICIA'][8]."</div>
			    		<a href=\"https://perds.000webhostapp.com/ProyectoFinal/miparte.php/?ID=".$destacados['ID'][8]."\"><div class=\"overlay\">
							<div class=\"text\">Ver mas...</div>
						</div></a>
			    	</div>
			  	</div>
			</div>
			<div class=\"col\">
				<a href=\"https://perds.000webhostapp.com/ProyectoFinal/miparte.php/?ID=".$recientes['ID'][0]."\"><div>
					<p class=\"fecha\">".$recientes['FECHA'][0]."</p>
					<p class=\"nombre-noticia\">".$recientes['NOMBRE_NOTICIA'][0]."</p>
				</div></a>
				<hr/>
				<a href=\"https://perds.000webhostapp.com/ProyectoFinal/miparte.php/?ID=".$recientes['ID'][1]."\"><div>
					<p class=\"fecha\">".$recientes['FECHA'][1]."</p>
					<p class=\"nombre-noticia\">".$recientes['NOMBRE_NOTICIA'][1]."</p>
				</div></a>
				<hr/>
				<a href=\"https://perds.000webhostapp.com/ProyectoFinal/miparte.php/?ID=".$recientes['ID'][2]."\"><div>
					<p class=\"fecha\">".$recientes['FECHA'][2]."</p>
					<p class=\"nombre-noticia\">".$recientes['NOMBRE_NOTICIA'][2]."</p>
				</div></a>
				<hr/>
				<a href=\"https://perds.000webhostapp.com/ProyectoFinal/miparte.php/?ID=".$recientes['ID'][3]."\"><div>
					<p class=\"fecha\">".$recientes['FECHA'][3]."</p>
					<p class=\"nombre-noticia\">".$recientes['NOMBRE_NOTICIA'][3]."</p>
				</div></a>
				<hr/>
				<a href=\"https://perds.000webhostapp.com/ProyectoFinal/miparte.php/?ID=".$recientes['ID'][4]."\"><div>
					<p class=\"fecha\">".$recientes['FECHA'][4]."</p>
					<p class=\"nombre-noticia\">".$recientes['NOMBRE_NOTICIA'][4]."</p>
				</div></a>
				<hr/>
				<a href=\"https://perds.000webhostapp.com/ProyectoFinal/miparte.php/?ID=".$recientes['ID'][5]."\"><div>
					<p class=\"fecha\">".$recientes['FECHA'][5]."</p>
					<p class=\"nombre-noticia\">".$recientes['NOMBRE_NOTICIA'][5]."</p>
				</div></a>
			</div>
		</div>
	</div>

    <footer>
    	<div class=\"pie\">
			<div class=\"info\">Info1</div>
			<a class=\"admin\" href=\"https://perds.000webhostapp.com/ProyectoFinal/login.php\"><div class=\"btn btn-outline-light btn-sm\">Edit</div></a>
    	</div>
    </footer>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src=\"https://code.jquery.com/jquery-3.3.1.slim.min.js\" integrity=\"sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo\" crossorigin=\"anonymous\"></script>
    <script src=\"https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js\" integrity=\"sha384-wHAiFfRlMFy6i5SRaxvfOCifBUQy1xHdJ/yoi7FRNXMRBu5WHdZYu1hA6ZOblgut\" crossorigin=\"anonymous\"></script>
    <script src=\"https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js\" integrity=\"sha384-B0UglyR+jN6CkvvICOB2joaf5I4l3gm9GU6Hc1og6Ls7i6U/mkkaduKaBhlAXv9k\" crossorigin=\"anonymous\"></script>
  </body>
</html>";
?>