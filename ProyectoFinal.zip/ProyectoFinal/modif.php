<?php

        require_once "conectar.php";
            $db = conectaDB();

            $idIng = $_POST['ID'];
            $nombre = $_POST['N_AUTOR'];
            $n_Noticia = $_POST['N_NOTICIA'];
            $imagen = $_POST['IMAGEN'];
            $texto = $_POST['NOTICIA'];
            $seccion = $_POST['seccion'];
                    
            $consulta = "SELECT * FROM NOTICIA WHERE ID = '$idIng'";
            $result = $db->query($consulta);
            //print"$result";
            if(!$result){ //significa que no existe el ID seleccionado
                print"<p>El ID seleccionado no existe en la base de datos.</p>\n";
         
            }else{
                $consulta2 = "UPDATE NOTICIA SET NOMBRE_AUTOR = '$nombre', NOMBRE_NOTICIA = '$n_Noticia', IMAGEN = '$imagen', TEXTO = '$texto', SECCION = '$seccion' WHERE ID = '$idIng'";
                $result2 = $db->query($consulta2);
                if(!$result2){//significa que no se pudo modificar
                    print "<p>Error no se modifico la noticia de manera exitosa.</p>\n";
                }else{
                    print"<p>Modificacion de la noticia y comentarios EXITOSA</p>\n";
                    
                }
                
            }
            print"<p><a href='modificar.php'>Atras</a></p>\n";
            print"<p><a href='modificaciones.php'>Pagina Principal</a></p>";
    
?>
