<!doctype html>
<html lang="en">
    <head>    <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
        <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css" integrity="sha384-GJzZqFGwb1QTTN6wy59ffF1BuGJpLSa9DkKMp0DgiMDm4iYMj70gZWKYbI706tWS" crossorigin="anonymous">
    
        <title>Modificar Noticia</title>
    </head>
    
    <body>
        <div class= 'conteiner-fluid' >
            <div class = 'd-flex justify-content-center'><img src = 'http://www.ieepco.org.mx/archivos/images/difusoresprep2018/logo_NVI.jpg' class = 'img-fluid' alt = 'Responsive image'></div>
            <h2 class = 'text-center'>Noticias actuales</h2>
            <?php
                require_once "conectar.php";
                $db = conectaDB();
                
                $consulta = "SELECT * FROM NOTICIA";
                $result = $db->query($consulta);
            ?>
            <div class = "table-responsive">
                <table class = "table table-striped">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>SECCION</th>
                            <th>NOMBRE_AUTOR</th>
                            <th>FECHA</th>
                            <th>NOMBRE_NOTICIA</th>
                            
                        </tr>
                    </thead>
                    <?php
                        if(!$result){
                            print "<p>Error en la consulta</p>\n";
                        }else{
                            foreach($result as $valor){ ?>
                                <tr>
                                    <td> <?php echo $valor['ID'] ?></td>
                                    <td> <?php echo $valor['SECCION'] ?></td>
                                    <td> <?php echo $valor['NOMBRE_AUTOR'] ?></td>
                                    <td> <?php echo $valor['FECHA'] ?></td>
                                    <td> <?php echo $valor['NOMBRE_NOTICIA'] ?></td>
                                </tr>
                           <?php }
                        }
                    ?>
                </table>
            </div>
            <h5 class = 'text-center'>Ingrese los datos de la noticia que desea modificar.</h5>
            <div class = "d-flex justify-content-center">
                
                <form action = "modif.php" method = "post">
                    <div class = "form-group">
                        <input type="number" class = "form-control" id = "ID" aria-describedby="ID" placeholder="Ingresa ID" name="ID">
                
                        <input type="text" class = "form-control" id = "N_AUTOR" aria-describedby="N_AUTOR" placeholder="Nombre del autor" name="N_AUTOR">

                        <input type="text" class = "form-control" id = "N_NOTICIA" aria-describedby="N_NOTICIA" placeholder="Nombre de la noticia" name="N_NOTICIA"> 

                        <input type="text" class = "form-control" id = "IMAGEN" aria-describedby="IMAGEN" placeholder="URL de la imagen" name="IMAGEN">

                        <textarea rows="10" cols="120" id = "NOTICIA" aria-describedby="NOTICIA" placeholder="texto de la noticia" name="NOTICIA"></textarea>
                        
                        <div class="form-group col-md-4">
                            <label for="seccion">SECCION</label>
                               <select id="seccion" class="form-control" name="seccion">
                                    <option selected>DEPORTES</option>
                                    <option selected>POLITICA</option>
                                    <option selected>CULTURA</option>
                              </select>
                            </div>
                    </div>

                    <p><button type = 'submit' class="btn btn-secondary btn-lg" name = 'boton' value = 'modificar'>Modificar</button></p>
                </form>


            </div>
            <p></p><a href='modificaciones.php'>Pagina Principal.</a></p>
        </div>
    </body>
</html>