<?php
session_start(); 
$_SESSION['logueado'] = TRUE;
?>
<!doctype html>
<html lang="en">
    <head>    <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
        <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css" integrity="sha384-GJzZqFGwb1QTTN6wy59ffF1BuGJpLSa9DkKMp0DgiMDm4iYMj70gZWKYbI706tWS" crossorigin="anonymous">
    
        <title>Modificaciones</title>
    </head>
    
    <body>
        <div class= 'conteiner-fluid' >
            <div class = "d-flex justify-content-end">
                <a href="salir.php">Cerrar Sesión</a>
            </div>
            <div class = 'd-flex justify-content-center'><img src = 'http://www.ieepco.org.mx/archivos/images/difusoresprep2018/logo_NVI.jpg' class = 'img-fluid' alt = 'Responsive image'></div>
            <h2 class = 'text-center'>Menu para realizar cambios en las noticias</h1>
            <h3 class = 'text-center'>¿Que accion desea realizar?</h3>
            <form action='agregar.php' method='post'>
        	    <p class = 'text-center'><button type='submit' class="btn btn-primary btn-lg" name='boton' value='crear'> Agregar Noticia </button></p>
        	</form>
        	<form action='modificar.php' method='post'>
        	    <p class = 'text-center'><button type='submit' class="btn btn-primary btn-lg" name='boton' value='modificar'> Modificar Noticia </button></p>
        	</form>
        	<form action='eliminar.php' method='post'>
        	    <p class = 'text-center'><button type='submit' class="btn btn-primary btn-lg" name='boton' value='eliminar'> Eliminar Noticia </button></p>
        	</form>
        	<form action='tabla.php' method='post'>
        	    <p class = 'text-center'><button type='submit' class="btn btn-primary btn-lg" name='boton' value='eliminar'>Tabla de Noticias </button></p>
        	</form>
    	</div>
        
    </body>
</html>