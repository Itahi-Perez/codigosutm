<?php
	//agrega.php
	require_once "conectar.php";

	$db = conectaDB();

    $nombre = $_POST['N_AUTOR'];
    $n_Noticia = $_POST['N_NOTICIA'];
    $imagen = $_POST['IMAGEN'];
    $texto = $_POST['NOTICIA'];
    $seccion = $_POST['seccion'];

    //print"$seccion";
            
    $consulta = "INSERT INTO NOTICIA (NOMBRE_AUTOR, NOMBRE_NOTICIA, IMAGEN, TEXTO, SECCION) VALUES ('$nombre', '$n_Noticia', '$imagen', '$texto', '$seccion')";
	$result = $db->query($consulta);
	if(!$result){//significa que no se pudo crear
		print "<p>Error no se agrego la noticia de manera exitosa.</p>\n";
	}else{
	    
		print"<p>Se agrego de la noticia de manera EXITOSA</p>\n";
		
	}
	print"<p><a href='agregar.php'>Atras</a></p>\n";
	print"<p><a href='modificaciones.php'>Pagina Principal</a></p>";
?>