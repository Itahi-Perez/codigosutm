<!doctype html>
<html lang="en">
    <head>    <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
        <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css" integrity="sha384-GJzZqFGwb1QTTN6wy59ffF1BuGJpLSa9DkKMp0DgiMDm4iYMj70gZWKYbI706tWS" crossorigin="anonymous">
    
        <title>Eliminar Noticia</title>
    </head>
    
    <body>
        <div class= 'conteiner-fluid' >
            <div class = 'd-flex justify-content-center'><img src = 'http://www.ieepco.org.mx/archivos/images/difusoresprep2018/logo_NVI.jpg' class = 'img-fluid' alt = 'Responsive image'></div>
            <h2 class = 'text-center'>Noticias actuales</h1>
            <?php
                require_once "conectar.php";
                $db = conectaDB();
                
                $consulta = "SELECT * FROM NOTICIA";
                $result = $db->query($consulta);
            ?>
            <div class = "table-responsive">
                <table class = "table table-striped">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>SECCION</th>
                            <th>NOMBRE_AUTOR</th>
                            <th>FECHA</th>
                            <th>NOMBRE_NOTICIA</th>
                            
                        </tr>
                    </thead>
                    <?php
                        if(!$result){
                            print "<p>Error en la consulta</p>\n";
                        }else{
                            foreach($result as $valor){ ?>
                                <tr>
                                    <td> <?php echo $valor['ID'] ?></td>
                                    <td> <?php echo $valor['SECCION'] ?></td>
                                    <td> <?php echo $valor['NOMBRE_AUTOR'] ?></td>
                                    <td> <?php echo $valor['FECHA'] ?></td>
                                    <td> <?php echo $valor['NOMBRE_NOTICIA'] ?></td>
                                </tr>
                           <?php }
                        }
                    ?>
                </table>
            </div>
            <div class = "d-flex justify-content-center">
                <form action = "eliminacion.php" method="post" >
                    <div class = "form-group">
                        <h5 class = 'text-center'>Ingrese el ID de la noticia a eliminar.</h5>
                        <input type="number" class="form-control" id="ID" aria-describedby="ID" placeholder="Ingresa ID" name="ID">
                        
                    </div>
                    <p><button type='submit' class="btn btn-secondary btn-lg" name='boton' value='eliminar'>Eliminar</button></p>
                </form>
                
            </div>
            
            
        </div>
        <p><a href='modificaciones.php'>Pagina Principal.</a></p>
    </body>
</html>