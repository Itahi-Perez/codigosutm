<!doctype html>
<html lang="en">
  <head>    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css" integrity="sha384-GJzZqFGwb1QTTN6wy59ffF1BuGJpLSa9DkKMp0DgiMDm4iYMj70gZWKYbI706tWS" crossorigin="anonymous">

    <title>Noticia</title>
  </head>
  <body>
    <?php
        require_once "conectar.php";
        $db = conectaDb();
       $n=$_REQUEST["ID"];
        $consultaN ="SELECT * FROM NOTICIA WHERE ID=$n";
        $consultaC ="SELECT * FROM COMENTARIOS WHERE IDN=$n";
       
        function consultaNoticia($consultaN,$db){
        $datos;
            $result = $db->query($consultaN);
            if (!$result) {
                print " <p>Error en la Noticia. No se encontro ninguna</p>\n";
            } 
            else{
                foreach ($result as $valor) {
                    $datos[]=$valor;
                }
            }
             return $datos;
        }
        
        function consultaComentarios($consultaC,$db){
            $datos2;
            $result = $db->query($consultaC);
            if (!$result) {
            } 
            else{
                foreach ($result as $valor){
                    $datos2[]=$valor;
                } 
            }
            return $datos2;

        }
        
        $salami=consultaNoticia($consultaN,$db);
        $id=$salami[0]["ID"];
        $autor = $salami[0]["NOMBRE_AUTOR"];
        $fecha = $salami[0]["FECHA"];
        $titulo = $salami[0]["NOMBRE_NOTICIA"];
        $imagen =$salami[0]["IMAGEN"];
        $texto = $salami[0]["TEXTO"];
        $comentarios = $salami[0]["COMENTARIOS"];
        $likes = $salami[0]["LIKES"];
        $peperoni = consultaComentarios($consultaC,$db);
       
        ?>
        
        
     <div class="p-3 mb-2 bg-dark text-white">
        <div class="d-flex bd-highlight">
          <div class="p-2 w-150 bd-highlight">
              <div class="d-flex flex-column bd-highlight mb-3">
                  <div class="p-3 mb-2 bg-danger text-white">
                      <?php 
                        print "<h2>      </h2> <br>";
                        print "<h2> $titulo </h2> <br>";
                        print "<h7>$autor    $fecha</h7> <br>";
                    ?>
                  </div>
                </div>
           
                <div class="d-flex flex-column bd-highlight mb-1">
                    <?php 
                        print "<img src=$imagen class='img-fluid' alt='Responsive image'>";
                    ?>
                </div>
                <div class="d-flex flex-column-reverse bd-highlight">
                    
                    <?php 
                        print "<p>   </p>";
                        print "<h5>$texto</h5>";
                    ?>
                </div>
                <div class="d-flex flex-row-reverse bd-highlight">
                    <div class="p-2 bd-highlight">
                        <?php
                            require_once "conectar.php";
                            $db=conectaDb();
                            function chekaLikes($cons,$n){
                                $datos;        
                                $consulta = "SELECT LIKES FROM NOTICIA WHERE ID=$n";
                                $result = $cons->query($consulta);
                                if (!$result) {
                                    print "    <p>Error en la consulta.</p>\n";
                                } else {
                                    foreach ($result as $valor) {
                                        $datos[]=$valor;
                                    }
                                }
                                return $datos;    
                            }
                        
                            function aumentaLikes($cons,$n,$cant){
                                $consulta = " UPDATE `NOTICIA` SET `LIKES`=$cant WHERE ID=$n";
                                $result = $cons->query($consulta);
                            }
                            
                            $likes=chekaLikes($db,$n);
                            $likes=$likes[0]["LIKES"];
                            if(isset($_POST['Like'])){
                                $_POST['Like']=null;;
                                $likes=$likes+1;
                                aumentaLikes($db,$n,$likes);
                            }
                        ?>
                          
                        <form method="POST" enctype="multipart/form-data">
                        		<input type="hidden" name="Id" value="<?php echo $n; ?>">
                        		<button type="submit" class="btn btn-primary" name="Like" value=1>Like<span class="badge"><?php echo $likes; ?></button>
                        </form>
                        </div>
                    </div>
                    
                    <?php
                        require_once "conectar.php";
                        $db=conectaDb();

                        if(isset($_REQUEST['btnComentar'])){
                            if($_REQUEST['nuevComen']!=NULL){
                                function creacomentario($db,$n,$coment){
                                    $consulta="INSERT INTO COMENTARIOS(`IDN`,`COMENTARIO`) VALUES ($n,'$coment')";
                                    $result=$db->query($consulta);
                                }
                                $com=$_REQUEST['nuevComen'];
                                creacomentario($db,$n,$com);
                            }
                        }
                    ?>
                    
                    <div class="d-flex justify-content-start">
                        <div class="p-3 mb-1 bg-success text-white"><p>Comentarios </p></div>
                    </div>
                    <div class="d-flex justify-content-start">
                        
                        <div class="d-flex flex-column bd-highlight mb-3">
                            
                            <div class="p-2 bd-highlight">
                              
                                <form action="" method="POST" enctype="multipart/form-data">
                                    
                                    <div class="form-group">
                                        
                                        <label for="exampleFormControlTextarea1">Subir Comentario</label>
                                        <input type="text" class="form-control" id="exampleFormControlTextarea2" aria-describedby="emailHelp" placeholder="Escriba aqui su comentario" name="nuevComen">
                                        <input type="hidden" name="ID" value=" <?php echo $n; ?>">
                                        
                                    </div>
                                    
                                    <button type="submit" class="btn btn-primary" name="btnComentar">Comentar</button>
                                </form>
                                
                            </div>
                            
                            <div class="p-2 bd-highlight">
                                <?php
                                    if($peperoni!=NULL){
                                        foreach ($peperoni as $valor) {
                                           print " <h8>".$valor["COMENTARIO"]."</h8><br> ";
                                        }
                                    }
                                    else{
                                        
                                    }
                                ?>
                            
                          </div>
                          
                        </div>
                        
                    </div>
                    
                </div>
        
          <div class="p-2 flex-shrink-1 bd-highlight">
              
              <div class="p-3 mb-2 bg-dark text-white">
                  
                <?php 
                    print "<img src='http://fotos.e-consulta.com/ositoportara.jpg' alt='Responsive image'class='img-fluid'>";
                    print "<img src='https://i.pinimg.com/originals/54/64/04/5464040987a72b0c8b5adb345ef09e54.jpg' alt='Responsive image'class='img-fluid'>";
                ?>
                
              </div>
            
          </div>
        </div>
  </div>
    

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js" integrity="sha384-wHAiFfRlMFy6i5SRaxvfOCifBUQy1xHdJ/yoi7FRNXMRBu5WHdZYu1hA6ZOblgut" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js" integrity="sha384-B0UglyR+jN6CkvvICOB2joaf5I4l3gm9GU6Hc1og6Ls7i6U/mkkaduKaBhlAXv9k" crossorigin="anonymous"></script>
  </body>
</html>