<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device=width, initial-scale=1, shrink-to-fit=no">

		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css" integrity="sha384-GJzZqFGwb1QTTN6wy59ffF1BuGJpLSa9DkKMp0DgiMDm4iYMj70gZWKYbI706tWS" crossorigin="anonymous">
		<title>LOGIN</title>
	</head>
	<body>
		<!-- logo y nombre del periodico   --> 
        <div class= 'conteiner-fluid' >	
            <div class = "d-flex justify-content-end">
                <a href="principal.php">Ir a página principal.</a>
            </div>
        	<div class"d-flex justify-content-end">
        	    <img src = 'http://www.ieepco.org.mx/archivos/images/difusoresprep2018/logo_NVI.jpg' class = 'img-fluid rounded mx-auto d-block' alt = 'Responsive image'>
        	</div>
            <div class="d-flex justify-content-center">
                <form action="login2.php" method="post">
                    <div class="form-group"> 
                   	    <h1>Iniciar sesión</h1>
            		    <label for="user">Usuario</label>
            		    <input type="text" class="form-control" name="user" id="user" placeholder="Ingrese Usuario" maxlength="15">
            		 </div>  
                    <div class="form-group">
            		    <label for="password">Contraseña</label>
            		    <input type="password" class="form-control" id="password" placeholder="Contraseña" name="password" maxlength="8">
            		</div>
            		<button type="submit" name="login" class="btn btn-primary">Iniciar Sesión</button>
                </form>
            </div>
        </div>
    </body>
</html>
