var seleccionado = 0, colSelect = 0, renSelect = 0, turno = 1, contadorNaranja=12, contadorVerde=12;
window.onload = function() {
	for(ren = 1; ren<= 8; ren++) {
		x = (ren % 2 == 0) ? 1 : 0;
		createRow(ren);
		for(col = 1; col <= 8; col++) {
			if(col % 2 == x) {
				createCol_black(ren,col);
				if(ren<=3){ 
					createfichas1(col,ren); 
				}
				if(ren>=6){
					createfichas2(col, ren);    
				} 
			}
			else
				createCol_white(ren,col);
		}  
	}
}
function createRow(element){
    var div = document.createElement("div");
    div.id = "row-"+ren;
    div.className ="row";
    document.getElementById("contenedor").appendChild(div);
}

function createCol_black(element){
	var div = document.createElement("div");
	div.className ="col-black";
	div.id = "col_black-"+ren+"-"+col;
	document.getElementById("row-"+ren).appendChild(div);
	var casillaNegra= document.getElementById("col_black-"+ren+"-"+col);
	casillaNegra.addEventListener("click", function () {
		movimientoFicha(casillaNegra);
		if(contadorVerde == 0 || contadorNaranja ==0){
			if(contadorVerde != 0){
				alert("¡WINNER PLAYER GREEN!");
			}
			else{
				alert("¡WINNER PLAYER ORANGE!");
			}
		}
	});
}

function createCol_white(element){
	var div = document.createElement("div");
	div.className ="col-white";
	div.id = "col_white-"+col;
	document.getElementById("row-"+ren).appendChild(div);
}

//Función que crea las fichas naranjas
function createfichas1(element){
	var div = document.createElement("div");
	div.className ="ficha1";
	document.getElementById("col_black-"+ren+"-"+col).appendChild(div);
	div.id = "ficha1-"+ren+"-"+col;
	var ficha = document.getElementById("ficha1-"+ren+"-"+col);
	ficha.setAttribute("fcol", col);
	ficha.setAttribute("fren", ren);
	var cas =  document.getElementById("col_black-"+ren+"-"+col);
	cas.setAttribute("ficha", ficha.getAttribute("id"));
}

function createfichas2(element){
	var div = document.createElement("div");
	div.className ="ficha2";
	document.getElementById("col_black-"+ren+"-"+col).appendChild(div);
	div.id = "ficha2-"+ren+"-"+col;
	var ficha = document.getElementById("ficha2-"+ren+"-"+col);
	ficha.setAttribute("fcol", col);
	ficha.setAttribute("fren", ren);
	var cas =  document.getElementById("col_black-"+ren+"-"+col);
	cas.setAttribute("ficha", ficha.getAttribute("id"));
}

function movimientoFicha(casillaNegra){
	var cadena = ""+casillaNegra.getAttribute("id");
	var fichaActual = casillaNegra.getAttribute("ficha");
	var casillaAnterior = document.getElementById("col_black-"+renSelect+"-"+colSelect);
	var subcadena = cadena.substring(10);
	var fichaTurno = 0;
	if (fichaActual != null){
		fichaTurno = fichaActual.substring(5,6);
	}
	if (casillaNegra.hasAttribute("ficha")&& fichaTurno == turno){
		if(casillaAnterior != null){
			casillaAnterior.className = "col-black";
		}
		casillaNegra.className = "col-black-2";
		seleccionado = 1;
		colSelect = document.getElementById(fichaActual).getAttribute("fcol");
		renSelect = document.getElementById(fichaActual).getAttribute("fren");
		
	}
	else if (seleccionado == 1 && turno == 1){
		var fichaAnterior = casillaAnterior.getAttribute("ficha");
		var nClase = document.getElementById(fichaAnterior).className;
		if(casillaNegra.hasAttribute("ficha")==false && nClase == "ficha1"){
			if(parseInt(subcadena[0])==8){
				document.getElementById(fichaAnterior).className = "fDamas1";
			}
			var condicion1 = (parseInt(renSelect) + 1 == parseInt(subcadena[0])) && (parseInt(colSelect)+1 == parseInt(subcadena[2]));
			var condicion2 = (parseInt(renSelect) + 1 == parseInt(subcadena[0])) && (parseInt(colSelect)-1 == parseInt(subcadena[2]));
			if(condicion1 || condicion2){
				casillaAnterior.className = "col-black";
				document.getElementById(fichaAnterior).setAttribute("fren", subcadena[0]);
				document.getElementById(fichaAnterior).setAttribute("fcol", subcadena[2]);
				casillaNegra.setAttribute("ficha", fichaAnterior);
				casillaNegra.appendChild(document.getElementById(fichaAnterior));
				casillaAnterior.removeAttribute("ficha");
				seleccionado = 0;
				turno = 2;
			}
			//-------------------------------------------------INSTRUCCIONES PARA COMER de la naranja a la verde ----------------------------------------------------------------
			var condicion3 = (parseInt(renSelect) + 2 == parseInt(subcadena[0])) && (parseInt(colSelect)+2 == parseInt(subcadena[2]));
			var condicion4 = (parseInt(renSelect) + 2 == parseInt(subcadena[0])) && (parseInt(colSelect)-2 == parseInt(subcadena[2]));
			var fichaAuxiliar = null;
			if(parseInt(renSelect)+1 < 9 && parseInt(colSelect)+1 <9){
				fichaAuxiliar = document.getElementById("col_black-"+ (parseInt(renSelect)+1) + "-" +(parseInt(colSelect)+1)).getAttribute("ficha");
			}
			var subcadena2 = 0;
			if(fichaAuxiliar != null){
				subcadena2 = fichaAuxiliar.substring(5,6);
			}
			var fichaAuxiliar2 = null;
			if(parseInt(renSelect)+1 < 9 && parseInt(colSelect)-1 >0){
				fichaAuxiliar2 = document.getElementById("col_black-"+ (parseInt(renSelect)+1) + "-" +(parseInt(colSelect)-1)).getAttribute("ficha");
			}
			var subcadena3 = 0;
			if(fichaAuxiliar2 != null){
				subcadena3 = fichaAuxiliar2.substring(5,6);
			}
			if(condicion3 && subcadena2 == "2"){
				var casillaAuxiliar = document.getElementById("col_black-"+ (parseInt(renSelect)+1) + "-" +(parseInt(colSelect)+1));
				casillaAuxiliar.removeAttribute("ficha");
				casillaAuxiliar.removeChild(document.getElementById(fichaAuxiliar));
				casillaAnterior.className = "col-black";
				document.getElementById(fichaAnterior).setAttribute("fren", subcadena[0]);
				document.getElementById(fichaAnterior).setAttribute("fcol", subcadena[2]);
				casillaNegra.setAttribute("ficha", fichaAnterior);
				casillaNegra.appendChild(document.getElementById(fichaAnterior));
				casillaAnterior.removeAttribute("ficha");
				seleccionado = 0;
				turno = 2;
				contadorVerde=contadorVerde-1;
			}
			else if (condicion4 && subcadena3 == "2"){
				var casillaAuxiliar = document.getElementById("col_black-"+ (parseInt(renSelect)+1) + "-" +(parseInt(colSelect)-1));
				casillaAuxiliar.removeAttribute("ficha");
				casillaAuxiliar.removeChild(document.getElementById(fichaAuxiliar2));
				casillaAnterior.className = "col-black";
				document.getElementById(fichaAnterior).setAttribute("fren", subcadena[0]);
				document.getElementById(fichaAnterior).setAttribute("fcol", subcadena[2]);
				casillaNegra.setAttribute("ficha", fichaAnterior);
				casillaNegra.appendChild(document.getElementById(fichaAnterior));
				casillaAnterior.removeAttribute("ficha");
				seleccionado = 0;
				turno = 2;
				contadorVerde=contadorVerde-1;
			}
		}
		//---------------------------------------------MOVIMIENTOS DE LA DAMA naranja---------------------------------------------------
		else if (casillaNegra.hasAttribute("ficha")==false && nClase == "fDamas1"){
			var condicion1 = (parseInt(renSelect) + 1 == parseInt(subcadena[0])) && (parseInt(colSelect)+1 == parseInt(subcadena[2]));
			var condicion2 = (parseInt(renSelect) + 1 == parseInt(subcadena[0])) && (parseInt(colSelect)-1 == parseInt(subcadena[2]));
			var condicion3 = (parseInt(renSelect) - 1 == parseInt(subcadena[0])) && (parseInt(colSelect)+1 == parseInt(subcadena[2]));
			var condicion4 = (parseInt(renSelect) - 1 == parseInt(subcadena[0])) && (parseInt(colSelect)-1 == parseInt(subcadena[2]));
			if(condicion1 || condicion2 || condicion3 || condicion4){
				casillaAnterior.className = "col-black";
				document.getElementById(fichaAnterior).setAttribute("fren", subcadena[0]);
				document.getElementById(fichaAnterior).setAttribute("fcol", subcadena[2]);
				casillaNegra.setAttribute("ficha", fichaAnterior);
				casillaNegra.appendChild(document.getElementById(fichaAnterior));
				casillaAnterior.removeAttribute("ficha");
				seleccionado = 0;
				turno = 2;
			}
			//-----------------------------------------------------COME LA DAMA---------------------------------------------------
			var condicion5 = (parseInt(renSelect) + 2 == parseInt(subcadena[0])) && (parseInt(colSelect)+2 == parseInt(subcadena[2]));
			var condicion6 = (parseInt(renSelect) + 2 == parseInt(subcadena[0])) && (parseInt(colSelect)-2 == parseInt(subcadena[2]));
			var condicion7 = (parseInt(renSelect) - 2 == parseInt(subcadena[0])) && (parseInt(colSelect)+2 == parseInt(subcadena[2]));
			var condicion8 = (parseInt(renSelect) - 2 == parseInt(subcadena[0])) && (parseInt(colSelect)-2 == parseInt(subcadena[2]));
			var fichaAuxiliar = null;
			if(parseInt(renSelect)+1 < 9 && parseInt(colSelect)+1 <9){
				fichaAuxiliar = document.getElementById("col_black-"+ (parseInt(renSelect)+1) + "-" +(parseInt(colSelect)+1)).getAttribute("ficha");
			}
			var subcadena2 = 0;
			if(fichaAuxiliar != null){
				subcadena2 = fichaAuxiliar.substring(5,6);
			}
			
			var fichaAuxiliar2 = null;
			if(parseInt(renSelect)+1 < 9 && parseInt(colSelect)-1 >0){
				fichaAuxiliar2 = document.getElementById("col_black-"+ (parseInt(renSelect)+1) + "-" +(parseInt(colSelect)-1)).getAttribute("ficha");
			}
			var subcadena3 = 0;
			if(fichaAuxiliar2 != null){
				subcadena3 = fichaAuxiliar2.substring(5,6);
			}
			
			var fichaAuxiliar3 = null;
			if(parseInt(renSelect)-1 > 0 && parseInt(colSelect)+1 < 9){
				fichaAuxiliar3 = document.getElementById("col_black-"+ (parseInt(renSelect)-1) + "-" +(parseInt(colSelect)+1)).getAttribute("ficha");
			}
			var subcadena4 = 0;
			if(fichaAuxiliar3 != null){
				subcadena4 = fichaAuxiliar3.substring(5,6);
			}
			
			var fichaAuxiliar4 = null;
			if(parseInt(renSelect)-1 > 0 && parseInt(colSelect)-1 > 0){
				fichaAuxiliar4 = document.getElementById("col_black-"+ (parseInt(renSelect)-1) + "-" +(parseInt(colSelect)-1)).getAttribute("ficha");
			}
			var subcadena5 = 0;
			if(fichaAuxiliar4 != null){
				subcadena5 = fichaAuxiliar4.substring(5,6);
			}
			
			if(condicion5 && subcadena2 == "2"){
				var casillaAuxiliar = document.getElementById("col_black-"+ (parseInt(renSelect)+1) + "-" +(parseInt(colSelect)+1));
				casillaAuxiliar.removeAttribute("ficha");
				casillaAuxiliar.removeChild(document.getElementById(fichaAuxiliar));
				casillaAnterior.className = "col-black";
				document.getElementById(fichaAnterior).setAttribute("fren", subcadena[0]);
				document.getElementById(fichaAnterior).setAttribute("fcol", subcadena[2]);
				casillaNegra.setAttribute("ficha", fichaAnterior);
				casillaNegra.appendChild(document.getElementById(fichaAnterior));
				casillaAnterior.removeAttribute("ficha");
				seleccionado = 0;
				turno = 2;
				contadorVerde=contadorVerde-1;
			}
			else if (condicion6 && subcadena3 == "2"){
				var casillaAuxiliar = document.getElementById("col_black-"+ (parseInt(renSelect)+1) + "-" +(parseInt(colSelect)-1));
				casillaAuxiliar.removeAttribute("ficha");
				casillaAuxiliar.removeChild(document.getElementById(fichaAuxiliar2));
				casillaAnterior.className = "col-black";
				document.getElementById(fichaAnterior).setAttribute("fren", subcadena[0]);
				document.getElementById(fichaAnterior).setAttribute("fcol", subcadena[2]);
				casillaNegra.setAttribute("ficha", fichaAnterior);
				casillaNegra.appendChild(document.getElementById(fichaAnterior));
				casillaAnterior.removeAttribute("ficha");
				seleccionado = 0;
				turno = 2;
				contadorVerde=contadorVerde-1;
			}
			else if (condicion7 && subcadena4 == "2"){
				var casillaAuxiliar = document.getElementById("col_black-"+ (parseInt(renSelect)-1) + "-" +(parseInt(colSelect)+1));
				casillaAuxiliar.removeAttribute("ficha");
				casillaAuxiliar.removeChild(document.getElementById(fichaAuxiliar3));
				casillaAnterior.className = "col-black";
				document.getElementById(fichaAnterior).setAttribute("fren", subcadena[0]);
				document.getElementById(fichaAnterior).setAttribute("fcol", subcadena[2]);
				casillaNegra.setAttribute("ficha", fichaAnterior);
				casillaNegra.appendChild(document.getElementById(fichaAnterior));
				casillaAnterior.removeAttribute("ficha");
				seleccionado = 0;
				seleccionado = 0;
				turno = 2;
				contadorVerde=contadorVerde-1;
			}
			else if (condicion8 && subcadena5 == "2"){
				var casillaAuxiliar = document.getElementById("col_black-"+ (parseInt(renSelect)-1) + "-" +(parseInt(colSelect)-1));
				casillaAuxiliar.removeAttribute("ficha");
				casillaAuxiliar.removeChild(document.getElementById(fichaAuxiliar4));
				casillaAnterior.className = "col-black";
				document.getElementById(fichaAnterior).setAttribute("fren", subcadena[0]);
				document.getElementById(fichaAnterior).setAttribute("fcol", subcadena[2]);
				casillaNegra.setAttribute("ficha", fichaAnterior);
				casillaNegra.appendChild(document.getElementById(fichaAnterior));
				casillaAnterior.removeAttribute("ficha");
				seleccionado = 0;
				turno = 2;
				contadorVerde=contadorVerde-1;
			}
		}
	}
	else if (seleccionado == 1 && turno == 2){
		var fichaAnterior = casillaAnterior.getAttribute("ficha");
		var nClase =document.getElementById(fichaAnterior).className;
		if(casillaNegra.hasAttribute("ficha")==false && nClase == "ficha2"){
			var condicion1 = (parseInt(renSelect) - 1 == parseInt(subcadena[0])) && (parseInt(colSelect)+1 == parseInt(subcadena[2]));
			var condicion2 = (parseInt(renSelect) - 1 == parseInt(subcadena[0])) && (parseInt(colSelect)-1 == parseInt(subcadena[2]));
			if(parseInt(subcadena[0])==1){
				document.getElementById(fichaAnterior).className = "fDamas2";
			}
			if(condicion1 || condicion2){
				casillaAnterior.className = "col-black";
				document.getElementById(fichaAnterior).setAttribute("fren", subcadena[0]);
				document.getElementById(fichaAnterior).setAttribute("fcol", subcadena[2]);
				casillaNegra.setAttribute("ficha", fichaAnterior);
				casillaNegra.appendChild(document.getElementById(fichaAnterior));
				casillaAnterior.removeAttribute("ficha");
				seleccionado = 0;
				turno = 1;

			}
			//-------------------------------------------------INSTRUCCIONES PARA COMER de la verde la naranja----------------------------------------------------------------
			var condicion3 = (parseInt(renSelect) - 2 == parseInt(subcadena[0])) && (parseInt(colSelect)+2 == parseInt(subcadena[2]));
			var condicion4 = (parseInt(renSelect) - 2 == parseInt(subcadena[0])) && (parseInt(colSelect)-2 == parseInt(subcadena[2]));
			var fichaAuxiliar = null;
			if(parseInt(renSelect)-1 > 0 && parseInt(colSelect)+1 <9){
				fichaAuxiliar = document.getElementById("col_black-"+ (parseInt(renSelect)-1) + "-" +(parseInt(colSelect)+1)).getAttribute("ficha");
			}
			var subcadena2 = 0;
			if(fichaAuxiliar != null){
				subcadena2 = fichaAuxiliar.substring(5,6);
			}
			var fichaAuxiliar2 = null;
			if(parseInt(renSelect)-1 > 0 && parseInt(colSelect)-1 >0){
				fichaAuxiliar2 = document.getElementById("col_black-"+ (parseInt(renSelect)-1) + "-" +(parseInt(colSelect)-1)).getAttribute("ficha");
			}
			var subcadena3 = 0;
			if(fichaAuxiliar2 != null){
				subcadena3 = fichaAuxiliar2.substring(5,6);
			}
			if(condicion3 && subcadena2 == "1"){
				var casillaAuxiliar = document.getElementById("col_black-"+ (parseInt(renSelect)-1) + "-" +(parseInt(colSelect)+1));
				casillaAuxiliar.removeAttribute("ficha");
				casillaAuxiliar.removeChild(document.getElementById(fichaAuxiliar));
				casillaAnterior.className = "col-black";
				document.getElementById(fichaAnterior).setAttribute("fren", subcadena[0]);
				document.getElementById(fichaAnterior).setAttribute("fcol", subcadena[2]);
				casillaNegra.setAttribute("ficha", fichaAnterior);
				casillaNegra.appendChild(document.getElementById(fichaAnterior));
				casillaAnterior.removeAttribute("ficha");
				seleccionado = 0;
				turno = 1;
				contadorNaranja=contadorNaranja-1;
			}
			else if (condicion4 && subcadena3 == "1"){
				var casillaAuxiliar = document.getElementById("col_black-"+ (parseInt(renSelect)-1) + "-" +(parseInt(colSelect)-1));
				casillaAuxiliar.removeAttribute("ficha");
				casillaAuxiliar.removeChild(document.getElementById(fichaAuxiliar2));
				casillaAnterior.className = "col-black";
				document.getElementById(fichaAnterior).setAttribute("fren", subcadena[0]);
				document.getElementById(fichaAnterior).setAttribute("fcol", subcadena[2]);
				casillaNegra.setAttribute("ficha", fichaAnterior);
				casillaNegra.appendChild(document.getElementById(fichaAnterior));
				casillaAnterior.removeAttribute("ficha");
				seleccionado = 0;
				turno = 1;
				contadorNaranja=contadorNaranja-1;
			}
		}
		//-------------------------------MOVIMIENTOS DE LA DAMA verde------------------------------------------------------
		else if(casillaNegra.hasAttribute("ficha")==false && nClase == "fDamas2"){
			var condicion1 = (parseInt(renSelect) - 1 == parseInt(subcadena[0])) && (parseInt(colSelect)+1 == parseInt(subcadena[2]));
			var condicion2 = (parseInt(renSelect) - 1 == parseInt(subcadena[0])) && (parseInt(colSelect)-1 == parseInt(subcadena[2]));
			var condicion3 = (parseInt(renSelect) + 1 == parseInt(subcadena[0])) && (parseInt(colSelect)+1 == parseInt(subcadena[2]));
			var condicion4 = (parseInt(renSelect) + 1 == parseInt(subcadena[0])) && (parseInt(colSelect)-1 == parseInt(subcadena[2]));
			if(condicion1 || condicion2 || condicion3 || condicion4){
				casillaAnterior.className = "col-black";
				document.getElementById(fichaAnterior).setAttribute("fren", subcadena[0]);
				document.getElementById(fichaAnterior).setAttribute("fcol", subcadena[2]);
				casillaNegra.setAttribute("ficha", fichaAnterior);
				casillaNegra.appendChild(document.getElementById(fichaAnterior));
				casillaAnterior.removeAttribute("ficha");
				seleccionado = 0;
				turno = 1;
			}
			//------------------COME DAMA verde----------------------------
			var condicion5 = (parseInt(renSelect) + 2 == parseInt(subcadena[0])) && (parseInt(colSelect)+2 == parseInt(subcadena[2]));
			var condicion6 = (parseInt(renSelect) + 2 == parseInt(subcadena[0])) && (parseInt(colSelect)-2 == parseInt(subcadena[2]));
			var condicion7 = (parseInt(renSelect) - 2 == parseInt(subcadena[0])) && (parseInt(colSelect)+2 == parseInt(subcadena[2]));
			var condicion8 = (parseInt(renSelect) - 2 == parseInt(subcadena[0])) && (parseInt(colSelect)-2 == parseInt(subcadena[2]));
			var fichaAuxiliar = null;
			if(parseInt(renSelect)+1 < 9 && parseInt(colSelect)+1 <9){
				fichaAuxiliar = document.getElementById("col_black-"+ (parseInt(renSelect)+1) + "-" +(parseInt(colSelect)+1)).getAttribute("ficha");
			}
			var subcadena2 = 0;
			if(fichaAuxiliar != null){
				subcadena2 = fichaAuxiliar.substring(5,6);
			}
			
			var fichaAuxiliar2 = null;
			if(parseInt(renSelect)+1 < 9 && parseInt(colSelect)-1 >0){
				fichaAuxiliar2 = document.getElementById("col_black-"+ (parseInt(renSelect)+1) + "-" +(parseInt(colSelect)-1)).getAttribute("ficha");
			}
			var subcadena3 = 0;
			if(fichaAuxiliar2 != null){
				subcadena3 = fichaAuxiliar2.substring(5,6);
			}
			
			var fichaAuxiliar3 = null;
			if(parseInt(renSelect)-1 > 0 && parseInt(colSelect)+1 < 9){
				fichaAuxiliar3 = document.getElementById("col_black-"+ (parseInt(renSelect)-1) + "-" +(parseInt(colSelect)+1)).getAttribute("ficha");
			}
			var subcadena4 = 0;
			if(fichaAuxiliar3 != null){
				subcadena4 = fichaAuxiliar3.substring(5,6);
			}
			
			var fichaAuxiliar4 = null;
			if(parseInt(renSelect)-1 > 0 && parseInt(colSelect)-1 > 0){
				fichaAuxiliar4 = document.getElementById("col_black-"+ (parseInt(renSelect)-1) + "-" +(parseInt(colSelect)-1)).getAttribute("ficha");
			}
			var subcadena5 = 0;
			if(fichaAuxiliar4 != null){
				subcadena5 = fichaAuxiliar4.substring(5,6);
			}
			
			if(condicion5 && subcadena2 == "1"){
				var casillaAuxiliar = document.getElementById("col_black-"+ (parseInt(renSelect)+1) + "-" +(parseInt(colSelect)+1));
				casillaAuxiliar.removeAttribute("ficha");
				casillaAuxiliar.removeChild(document.getElementById(fichaAuxiliar));
				casillaAnterior.className = "col-black";
				document.getElementById(fichaAnterior).setAttribute("fren", subcadena[0]);
				document.getElementById(fichaAnterior).setAttribute("fcol", subcadena[2]);
				casillaNegra.setAttribute("ficha", fichaAnterior);
				casillaNegra.appendChild(document.getElementById(fichaAnterior));
				casillaAnterior.removeAttribute("ficha");
				seleccionado = 0;
				turno = 1;
				contadorNaranja=contadorNaranja-1;
			}
			else if (condicion6 && subcadena3 == "1"){
				var casillaAuxiliar = document.getElementById("col_black-"+ (parseInt(renSelect)+1) + "-" +(parseInt(colSelect)-1));
				casillaAuxiliar.removeAttribute("ficha");
				casillaAuxiliar.removeChild(document.getElementById(fichaAuxiliar2));
				casillaAnterior.className = "col-black";
				document.getElementById(fichaAnterior).setAttribute("fren", subcadena[0]);
				document.getElementById(fichaAnterior).setAttribute("fcol", subcadena[2]);
				casillaNegra.setAttribute("ficha", fichaAnterior);
				casillaNegra.appendChild(document.getElementById(fichaAnterior));
				casillaAnterior.removeAttribute("ficha");
				seleccionado = 0;
				turno = 1;
				contadorNaranja=contadorNaranja-1;
			}
			else if (condicion7 && subcadena4 == "1"){
				var casillaAuxiliar = document.getElementById("col_black-"+ (parseInt(renSelect)-1) + "-" +(parseInt(colSelect)+1));
				casillaAuxiliar.removeAttribute("ficha");
				casillaAuxiliar.removeChild(document.getElementById(fichaAuxiliar3));
				casillaAnterior.className = "col-black";
				document.getElementById(fichaAnterior).setAttribute("fren", subcadena[0]);
				document.getElementById(fichaAnterior).setAttribute("fcol", subcadena[2]);
				casillaNegra.setAttribute("ficha", fichaAnterior);
				casillaNegra.appendChild(document.getElementById(fichaAnterior));
				casillaAnterior.removeAttribute("ficha");
				seleccionado = 0;
				seleccionado = 0;
				turno = 1;
				contadorNaranja=contadorNaranja-1;
			}
			else if (condicion8 && subcadena5 == "1"){
				var casillaAuxiliar = document.getElementById("col_black-"+ (parseInt(renSelect)-1) + "-" +(parseInt(colSelect)-1));
				casillaAuxiliar.removeAttribute("ficha");
				casillaAuxiliar.removeChild(document.getElementById(fichaAuxiliar4));
				casillaAnterior.className = "col-black";
				document.getElementById(fichaAnterior).setAttribute("fren", subcadena[0]);
				document.getElementById(fichaAnterior).setAttribute("fcol", subcadena[2]);
				casillaNegra.setAttribute("ficha", fichaAnterior);
				casillaNegra.appendChild(document.getElementById(fichaAnterior));
				casillaAnterior.removeAttribute("ficha");
				seleccionado = 0;
				turno = 1;
				contadorNaranja=contadorNaranja-1;
			}
		}
	}
}   