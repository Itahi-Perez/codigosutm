<?php

    require_once 'conectaBD.php';
    $db = conectaDB();
    
    $dbTabla="persona";
    $idIng = $_POST['id'];
    
    $consulta = "DELETE FROM $dbTabla WHERE id='$idIng'";
    $result = $db->query($consulta);
    if (!$result) {
        print "    <p>Error no se logro eliminar.</p>\n";
    } else {
        print"<p>Eliminación exitosa</p>";
         print"<a href='principal.php'>Pagina Principal.</a>";
    }

    $db = null;
    
?>