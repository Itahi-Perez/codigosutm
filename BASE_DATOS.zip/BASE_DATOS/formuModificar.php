<?php
    $idIn = $_POST['id'];
    print"<!DOCTYPE html>
        <html lang='en'>
          <head>
            <meta charset='UTF-8'/>
            <title>Formulario Modificar</title>	
          </head>
          <body>
            <form action='formuModif.php' method='post'>
        	    <h1>MODIFICAR REGISTRO</h1>
        	         
    
        	     <p>Nombre: <input type='text' name='nombre'/></p>
        	    <p>Apellidos: <input type='apellidos' name='apellidos'/></p>
        	    <p>Sexo: <input type='text' name='sexo'/></p>
        	    <p>Edad: <input type='number' name='edad'/></p>
        	    <p>Dirección: <input type='text' name='direccion'/></p>
        	    <input type='hidden' name='id' value='$idIn'/>
        	    
        	    <p><button type='submit' name='boton' value='modificar'> Modificar Registro </button></p>
        	</form>
          </body>
        </html>"
?>