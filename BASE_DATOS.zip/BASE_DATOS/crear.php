<?php
    require_once 'conectaBD.php';
    $db = conectaDB();
    
    $dbTabla="persona";
    $nomIng = $_POST['nombre'];
    $apeIng = $_POST['apellidos'];
    $sxIng = $_POST['sexo'];
    $edadIng = $_POST['edad'];
    $dirIng = $_POST['direccion'];
    
    $consulta = "INSERT INTO $dbTabla (nombre,apellido,sexo,edad,dirección) VALUES ('$nomIng','$apeIng','$sxIng','$edadIng','$dirIng')";
    $result = $db->query($consulta);
    if (!$result) {
        print " <p>Error no se logro crear nuevo registro.</p>\n";
    } else {
        print"<p>Nuevo Registro :)</p>";
        print"<a href='principal.php'>Pagina Principal.</a>";
    }

    $db = null;
    
?>