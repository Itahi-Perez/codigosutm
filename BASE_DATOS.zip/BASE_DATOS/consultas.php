<?php
    print"<h1>CONSULTAR REGISTROS</h1>";
    
    
    require_once "conectaBD.php";
    
    $db = conectaDB();
    $dbTabla = "persona";
    $consulta = "SELECT *FROM $dbTabla";
    $result = $db->query($consulta);
    if(!$result){
        print "<p>Error en la consulta</p>\n";
    }else{
        foreach($result as $valor){
            print "<p>$valor[id] $valor[nombre] $valor[apellido] $valor[sexo] $valor[edad] $valor[dirección] </p>";
        }
    }
    $db = null;
    print "<!DOCTYPE html>
    <html lang='en'>
      <head>
        <meta charset='UTF-8'/>
        <title>Consultar Registro</title>	
      </head>
      <body>
        <form action='principal.php' method='post'>
    		<p><button type='submit' name='boton' value='inicio'> Inicio </button></p>
    	</form>

      </body>
    </html>"

    	
?>