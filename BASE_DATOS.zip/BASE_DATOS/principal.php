<?php
    
    print "<!DOCTYPE html>
    <html lang='en'>
      <head>
        <meta charset='UTF-8'/>
        <title>Modificar Usuario</title>	
      </head>
      <body>
        <h1>Operaciones con bases de datos.</h1>
        <form action='consultas.php' method='post'>
    	  	<p><button type='submit' name='boton' value='consultar'> Consultar Registro </button></p>
    	</form>
    	<form action='crear.html' method='post'>
    	    <p><button type='submit' name='boton' value='crear'> Crear Registro </button></p>
    	</form>
    	<form action='modificar.html' method='post'>
    	    <p><button type='submit' name='boton' value='modificar'> Modificar Registro </button></p>
    	</form>
    	<form action='eliminar.html' method='post'>
    	    <p><button type='submit' name='boton' value='eliminar'> Eliminar Registro </button></p>
    	</form>
      </body>
    </html>"
?>