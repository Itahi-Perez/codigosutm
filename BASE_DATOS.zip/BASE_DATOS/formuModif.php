<?php
    
    require_once 'conectaBD.php';
    $db = conectaDB();
    
    $dbTabla="persona";
    $idIng = $_POST['id'];
    $nombre = $_POST['nombre'];
    $apellido = $_POST['apellidos'];
    $sexo = $_POST['sexo'];
    $direccion = $_POST['direccion'];
    $edad = $_POST['edad'];
    
    
    $consulta = "SELECT * FROM $dbTabla WHERE id='$idIng'";
    $result = $db->query($consulta);
    if (!$result){
        print "<p>No se encontro el registro.</p>";
        print"<p>$idIng</p>";
    }else {
        print "<p>SI se encontro el registro.</p>";
        print"<p>$idIng</p>";
        $consulta2 = "UPDATE $dbTabla SET nombre = '$nombre', apellido = '$apellido',sexo = '$sexo', edad = '$edad', dirección = '$direccion' WHERE id = $idIng ";
         $result2 = $db->query($consulta2);
        if (!$result2) {
            print "    <p>Error no se logro Modificar el registro.</p>\n";
        } else {
           
            print"<p>Modificacion exitosa</p>";
             print"<a href='principal.php'>Pagina Principal.</a>";
        }
    }
       $db = null;
        
    
?>	